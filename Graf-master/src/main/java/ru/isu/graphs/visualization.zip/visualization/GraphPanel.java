package ru.isu.graphs.visualization;

import ru.isu.graphs.object.Player;
import ru.isu.graphs.object.Vertex;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GraphPanel extends JPanel {

    ArrayList<Vertex> vertexList;
   // ArrayList<Vertex> neighboursList;
    public GraphPanel(ArrayList<Vertex> vertexes) {

        vertexList = vertexes;
    }

    public void paint(Graphics g) {

        for (int i = 0; i < vertexList.size(); i++) {
            g.setColor(Color.ORANGE);
          Vertex v=vertexList.get(i);

            g.fillOval(v.x, v.y,10, 10);//Р·Р°Р»РёРІРєР° С„РёРіСѓСЂС‹

            for (int j = 0; j <  v.neighboursLenght(); j++)
            {
                Vertex n=vertexList.get(v.getneighbour(j));

                  g.drawLine(v.x+5, v.y +5, n.x+5, n.y+5);
            }
        }


    }
}
