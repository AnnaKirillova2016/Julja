//package ru.isu.graphs.visualization;
//
//
//import javax.swing.*;
//
//public class Frame /*extends MouseEvent*/{
//    public static void main(String[] args) {
//        JFrame GraphFrame= new JFrame("Game");
//        GraphFrame.setVisible(true);
//        GraphFrame.setContentPane(new JPanel());
//        GraphFrame.setSize(1200, 800);
//    }
//}
