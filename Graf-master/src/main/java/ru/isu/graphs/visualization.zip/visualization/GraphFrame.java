package ru.isu.graphs.visualization;
import ru.isu.graphs.object.Graph;
import ru.isu.graphs.object.Player;
import ru.isu.graphs.object.Vertex;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GraphFrame extends JFrame {

    GraphPanel panel;
    ArrayList<Vertex> vertexList;

    public GraphFrame(String name) throws HeadlessException {
        super(name);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 1000);//СЂР°Р·РјРµСЂ
        setVisible(true);
        setBackground(Color.white);
    }

    public void SetVertexList(ArrayList<Vertex> vertexes)
    {
        this.vertexList = vertexes;
    }

    public  void drawPanel()
    {
        panel = new GraphPanel(vertexList);
        panel.setOpaque(true);
        panel.addMouseListener(new MouseEvent());
        getContentPane().removeAll();
        setContentPane(panel);

    }
}
